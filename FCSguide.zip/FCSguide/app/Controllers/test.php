<?php

namespace App\Controllers;

class Test extends BaseController
{
    public function index()
    {
        return view('home'); // Load view 'home.php'
    }
}
