<!DOCTYPE html>
<html>
<head>
    <title>FCSguide</title>
</head>
<body>
    <h1>Selamat Datang ke FCSguide</h1>
    <p>Ini adalah laman utama yang kita buat sendiri.</p>
</body>
</html>
